
        async gif2webp(buff){
            /*
            Nenge.addJS(Nenge.JSpath+'common_webp.js')
            buff = await Nenge.FetchItem('test.gif');
            Nenge.gif2webp(buff);
            */
            if(!T.image2webp_encode) await T.image2webp_load();
            if(typeof modernGif == 'undefined') await T.image2webp_gif();
            var frames  = await modernGif.decodeFrames(buff),newframes=[];
            var encoder = T.image2webp_WebpEncoder;
            let frameOptions = {
                duration: frames[0].delay,
                quality: 60,
                method: 0,
                lossless: !1,
                exact: !1,
            };
            encoder.init(frameOptions);
            for(var i=0;i<frames.length;i++){
                var frame = frames[i];
                encoder.push(frame.imageData,frame.width ,frame.height,{duration:frame.delay});
            }
            newframes =  encoder.encode();
            let file = new File([newframes],'xx.webp',{type:'image/webp'});
            document.body.appendChild(T.$ct('div','<img src="'+F.URL(file)+'">'));
            return newframes;
        },
        async image2webp_gif(){
            let mask = T.image2webp_mask();
            let files = await T.FetchItem({
                url:T.JSpath+'zip/webp_gif.zip',
                unpack:!0,
                store:'libjs',
                progress(a,b,c,d){
                    mask[2].innerHTML = F.getname(a);
                    if(b)mask[1].value = parseInt(b);
                }
            });
            await T.addJS(files['modernGif.js']);
            await T.addJS(files['WebpEncoder.js']);
            T.image2webp_WebpEncoder = new (await WebpEncoder({wasmBinary:files['WebpEncoder.wasm']})).WebpEncoder();
            mask[0].remove();

        },